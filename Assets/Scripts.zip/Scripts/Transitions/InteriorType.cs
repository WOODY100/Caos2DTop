public enum InteriorType
{
    SameScene,   // casas, cuevas peque�as
    NewScene     // dungeons, interiores grandes
}
