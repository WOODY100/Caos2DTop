public enum GameState
{
    Boot,        // Juego reci�n iniciado
    Menu,        // Men� principal
    Playing,     // Gameplay normal
    Paused,      // PauseMenu
    Inventory,   // Inventario abierto
    Loot,        // Ventana de loot
    LevelUp,     // Selecci�n de nivel
    Dialogue,    // NPC / Cutscene
    Transition,  // Cambio de escena
    GameOver
}
