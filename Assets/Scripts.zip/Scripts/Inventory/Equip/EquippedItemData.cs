[System.Serializable]
public class EquippedItemData
{
    public ItemType slotType;
    public string itemID;
}
