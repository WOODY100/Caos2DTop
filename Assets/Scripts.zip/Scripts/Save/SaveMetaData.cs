[System.Serializable]
public class SaveMetaData
{
    public string saveName;
    public string sceneName;
    public int playerLevel;
    public string lastPlayed;
}
