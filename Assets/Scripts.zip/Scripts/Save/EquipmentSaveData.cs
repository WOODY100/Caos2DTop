using System.Collections.Generic;

[System.Serializable]
public class EquipmentSaveData
{
    public List<EquippedItemData> equippedItems;
}