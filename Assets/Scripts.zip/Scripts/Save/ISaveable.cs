public interface ISaveable
{
    void SaveData(SaveData data);
    void LoadData(SaveData data);
}