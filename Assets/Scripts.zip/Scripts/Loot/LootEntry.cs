using UnityEngine;

[System.Serializable]
public class LootEntry
{
    public ItemData item;
    public int amount = 1;
}
