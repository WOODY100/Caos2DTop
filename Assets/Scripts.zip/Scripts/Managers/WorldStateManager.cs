﻿using System.Collections.Generic;
using UnityEngine;

public class WorldStateManager : MonoBehaviour, ISaveable
{
    public static WorldStateManager Instance;

    private HashSet<string> openedChests = new();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    // ======================
    // CHESTS
    // ======================

    public void MarkChestOpened(string chestID)
    {
        if (string.IsNullOrEmpty(chestID))
            return;

        openedChests.Add(chestID);
    }

    public bool IsChestOpened(string chestID)
    {
        return openedChests.Contains(chestID);
    }

    // ======================
    // ENEMIES
    // ======================

    private HashSet<string> deadEnemies = new();

    public void MarkEnemyDead(string enemyID)
    {
        if (string.IsNullOrEmpty(enemyID))
            return;

        deadEnemies.Add(enemyID);
    }

    public bool IsEnemyDead(string enemyID)
    {
        return deadEnemies.Contains(enemyID);
    }


    // ======================
    // SAVE / LOAD
    // ======================

    public void SaveData(SaveData data)
    {
        data.openedChests.Clear();
        data.openedChests.AddRange(openedChests);

        data.deadEnemies.Clear();
        data.deadEnemies.AddRange(deadEnemies);
    }

    public void LoadData(SaveData data)
    {
        openedChests.Clear();
        deadEnemies.Clear();

        if (data.openedChests != null)
        {
            foreach (var id in data.openedChests)
                openedChests.Add(id);
        }
        if (data.deadEnemies != null)
        {
            foreach (var id in data.deadEnemies)
                deadEnemies.Add(id);
        }            
    }
}
